
while True:
      print("What is your name?")
      name = input()
      if name != "Nicholas":
            continue
            print('Hello, Nicholas. Is your password swordfish ?')
            password = input()
            if password == 'swordfish':
                  break
                  print('Access granted.')