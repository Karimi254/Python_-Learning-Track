while True:
    print('Whats your name buddy!')
    name = input()
    if name == 'your name'):
    break
    print('Thank you')
